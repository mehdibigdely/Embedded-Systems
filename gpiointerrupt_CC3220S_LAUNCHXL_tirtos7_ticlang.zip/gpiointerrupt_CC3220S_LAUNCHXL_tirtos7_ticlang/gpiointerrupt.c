/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * * Neither the name of Texas Instruments Incorporated nor the names of
 * its contributors may be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
/*
 * ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>
/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/Timer.h>
/* Driver configuration */
#include "ti_drivers_config.h"

// defining different states for our Morse code displaying application
enum STATES_OF_BUTTONS {SOS, OK} BUTTON_STATE, BUTTON_INITIAL_STATE;
// it will be used to iterate SOS and OK LED array members
unsigned char j = 0;
// used to read LEDs arrays' state
unsigned char state;
// used to keep the size of SOS and OK arrays
int sizeOfSosArray, sizeOfOkArray;
/*
this array will guide state machine in turning red or green LEDs onn or off, based on our Morse code
LED colors: integer value of Red is 255, and green is 65280 (used 65 instead of 65280); 0 represents off
S:  ▄ ▄ ▄    O: ▄▄▄ ▄▄▄ ▄▄▄  K: ▄▄▄ ▄ ▄▄▄
in other word, dot ▄ will be represented by 255, dash ▄▄▄ represented by 65, and blank using 0
the chosen values for dot and dash are arbitrary, and could be any other value, as long as we stay consistent & follow a logic
*/
int SOS_SIGNAL_LEDs[] =
{
    255,0,255,0,255, // "S" or "dot dot dot" & will be shown using Red that flash 3 times, and blank or 0 (both lights off) for 2 times- 500 ms each => 2500 ms total
    0,0,0, // space or blank for 3 times => 1500 ms total
    65,65,65,0,65,65,65,0,65,65,65, // "O" or "dash dash dash" & will flash Green 3 times (each flashing is 3 units or 1500 ms) => 5500 ms total
    0,0,0, // space or blank for 3 times => 1500 ms total
    255,0,255,0,255, // Red will flash 3 times, and blank or 0 for 2 times- 500 ms each => 2500 ms total
    0,0,0,0,0,0 // blank, space or break between words for 5 times => 2500 ms total
    // above we had "S blank O blank S blank blank" or "Red blank Green blank Red blank blank"
};
sizeOfSosArray = sizeof(SOS_SIGNAL_LEDs) / sizeof(SOS_SIGNAL_LEDs[0]);

int OK_SIGNAL_LEDs[] =
{
     65,65,65,0,65,65,65,0,65,65,65, // O or "dash dash dash" in Morse, is shown by Green here & will flash 3 times (each flashing is 3 units or 1500 ms) + 2 blanks => 5500 ms total
     0,0,0, // space or blank for 3 times => 1500 ms total
     65,65,65,0,255,0,65,65,65, // K or dash dot dash in Morse shown by Green(3 units), blank, Red, Green(3 units) => 4500 ms total
     0,0,0,0,0,0 // blank, space or break between words for 65 times => 255500 ms total
     // above we had "O blank "
};
sizeOfOkArray = sizeof(OK_SIGNAL_LEDs) / sizeof(OK_SIGNAL_LEDs[0]);

void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{
     if (BUTTON_INITIAL_STATE == SOS) {
         state = SOS_SIGNAL_LEDs[j]; // this will set state of SOS_SIGNAL_LEDs array
         switch(state) {
             case 0:// as mentioned above, 0 will turn both lights off for blank, break and used between words or signals
                 GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
                 GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
                 break;
             case 255: // as mentioned above, 2 represent Red and this will turn on Red LED
                 GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
                 GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
                 break;
             case 65:// as mentioned above, 65 represent Green(short version of integer value for Green which is 6525580) and this will turn on Green LED
                 GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
                 GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
                 break;
     }

        j++; // Increment j to iterate all array's elements, one by one

        if (j == sizeOfSosArray){ // will set the initial state of button to current state (SOS) when reaching the last element of array
            BUTTON_INITIAL_STATE = BUTTON_STATE;
            j = 0; // will set the j to 0 that will cause timerCallback to start from the beginning of the SOS array
        }
    }
    if (BUTTON_INITIAL_STATE == OK) {
        state = OK_SIGNAL_LEDs[j]; // will set the LED state to OK_SIGNAL_LEDs array
        switch(state) {
            case 0:// will turn both lights off for blank, break and used between words or signals
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
                break;
            case 255:// 255 represent Red and this will turn on Red LED
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
                break;
            case 65:// 65 represent Green(short version of integer value for Green which is 65280) and this will turn on Green LED
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
                break;
        }
        j++; // Increment j to iterate all array's elements, one by one
        if (j ==  sizeOfOkArray){ // will set the initial state of button to current state (OK) when reaching the last element of array
            BUTTON_INITIAL_STATE = BUTTON_STATE;
            j = 0; //  will set the j to 0 that will cause timerCallback to start from the beginning of the OK array
        }
    }
}
void initTimer(void){
     Timer_Handle timer0;
     Timer_Params params;
     Timer_init();
     Timer_Params_init(&params);
     params.period = 500000;
     params.periodUnits = Timer_PERIOD_US;
     params.timerMode = Timer_CONTINUOUS_CALLBACK;
     params.timerCallback = timerCallback;
     timer0 = Timer_open(CONFIG_TIMER_0, &params);
     if (timer0 == NULL) {
         /* Failed to initialized timer */
         while (1) {}
     }
     if (Timer_start(timer0) == Timer_STATUS_ERROR) {
         /* Failed to start timer */
         while (1) {}
     }
}
/*
 * *****UNUSED BUTTON*****
 * ======== gpioButtonFxn0 ========
 * Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0.
 *
 * Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn0(uint_least8_t index)
{
}
/*
 * ======== gpioButtonFxn1 ========
 * Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_1.
 * This may not be used for all boards.
 *
 * Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn1(uint_least8_t index)
{
    // this will change/reverse the BUTTON_STATE based on the current BUTTON_INITIAL_STATE
    (BUTTON_INITIAL_STATE == OK ) ? (BUTTON_STATE = SOS) : (BUTTON_STATE = OK);
}
/*
 * ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    /* Call driver init functions */
    GPIO_init();
    initTimer();
    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_LED_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);
    /* Turn off user LED */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
    GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);

    /* Install Button callback */
        // button 1 is the only key that can set callback function (changing states from SOS to OK or vice versa)
    GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);
    /* Enable interrupts */
    GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    /*
    * If more than one input pin is available for your device, interrupts
    * will be enabled on CONFIG_GPIO_BUTTON1.
    */
    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1) {
        // this configures BUTTON1 pin
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU |
        GPIO_CFG_IN_INT_FALLING);
        // this installs button callback
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    }
    // returns Null upon successful completion of the l
}
